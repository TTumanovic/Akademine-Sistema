﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Microsoft.Data.SqlClient;

namespace Akademine_Sistema
{
    public partial class Form6 : Form
    {
        private Dalykai subjectManager = new Dalykai();
        private Connect dbConnection = new Connect();

        public Form6()
        {
            InitializeComponent();
            LoadGroups();
            LoadProfessors();
            DisplayDalykai();
        }

        private void LoadGroups()
        {
            try
            {
                DataTable dt = subjectManager.GetGroups();
                cmbGroups.DataSource = dt;
                cmbGroups.DisplayMember = "groupName";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading groups: {ex.Message}");
            }
        }

        private void LoadProfessors()
        {
            try
            {
                DataTable dt = subjectManager.GetProfessors();
                cmbProfessors.DataSource = dt;
                cmbProfessors.DisplayMember = "name";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading professors: {ex.Message}");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (ValidateInputs())
            {
                string subjectName = txtSubjectName.Text;
                string groupName = ((DataRowView)cmbGroups.SelectedItem)["groupName"].ToString();
                string professor = ((DataRowView)cmbProfessors.SelectedItem)["name"].ToString();

                bool success = subjectManager.AddSubject(subjectName, groupName, professor);
                if (success)
                {
                    MessageBox.Show("Subject added successfully!");
                    DisplayDalykai();
                }
                else
                {
                    MessageBox.Show("Error adding subject.");
                }
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (ValidateInputs())
            {
                string subjectName = txtSubjectName.Text;
                string groupName = ((DataRowView)cmbGroups.SelectedItem)["groupName"].ToString();
                string professor = ((DataRowView)cmbProfessors.SelectedItem)["name"].ToString();

                bool success = subjectManager.DeleteSubject(subjectName, groupName, professor);
                if (success)
                {
                    MessageBox.Show("Subject deleted successfully!");
                    DisplayDalykai();
                }
                else
                {
                    MessageBox.Show("Error deleting subject.");
                }
            }
        }
        public void DisplayDalykai()
        {

            Dalykai dal = new Dalykai();

            DataTable dt = dal.GetDalykai();

            dataGridView1.DataSource = dt;
        }
        private bool ValidateInputs()
        {
            if (string.IsNullOrWhiteSpace(txtSubjectName.Text))
            {
                MessageBox.Show("Please fill in the subject name.");
                return false;
            }
            if (cmbGroups.SelectedItem == null)
            {
                MessageBox.Show("Please select a group.");
                return false;
            }
            if (cmbProfessors.SelectedItem == null)
            {
                MessageBox.Show("Please select a professor.");
                return false;
            }
            return true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
            this.Close();
        }
    }
}
