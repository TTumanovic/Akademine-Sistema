﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Akademine_Sistema
{
    public partial class Form5 : Form
    {
        private Destytojai destytojasManager = new Destytojai();
        private Connect dbConnection = new Connect();

        public Form5()
        {
            InitializeComponent();
            DisplayProfessors();
        }

        public void DisplayProfessors()
        {
            try
            {
                DataTable dt = destytojasManager.GetProfessors();
                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error fetching professors: {ex.Message}");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (ValidateInputs())
            {
                string name = textBox1.Text;
                string surname = textBox2.Text;
                string username = textBox3.Text;
                string password = textBox4.Text;


                bool success = destytojasManager.AddProfessor(name, surname, username, password);
                if (success)
                {
                    MessageBox.Show("Professor added successfully!");
                    DisplayProfessors();
                }
                else
                {
                    MessageBox.Show("Error adding professor.");
                }
            }
        }


        private void button2_Click(object sender, EventArgs e)
        {
            if (ValidateInputs())
            {
                string username = textBox3.Text;
                string password = textBox4.Text;

                bool success = destytojasManager.DeleteProfessor(username, password);
                if (success)
                {
                    MessageBox.Show("Professor deleted successfully!");
                    DisplayProfessors(); 
                }
                else
                {
                    MessageBox.Show("Error deleting professor. Check if the username and password are correct.");
                }
            }
            else
            {
                MessageBox.Show("Please ensure all fields are filled in correctly.");
            }
        }


        private bool ValidateInputs()
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text) ||
                string.IsNullOrWhiteSpace(textBox2.Text) ||
                string.IsNullOrWhiteSpace(textBox3.Text) ||
                string.IsNullOrWhiteSpace(textBox4.Text))

            {
                MessageBox.Show("Please fill in all fields.");
                return false;
            }
            return true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
            this.Close();
        }

      

    }
}
