﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using System.Data.SqlClient;
using System.Runtime.Serialization;
using System.Diagnostics;

namespace Akademine_Sistema
{
    public partial class Form7 : Form
    {
        PridPaz PP = new PridPaz();
        private Connect dbConnection = new Connect();
        public Form7(string username, string password)
        {
            InitializeComponent();
            LoadGroups();
            LoadStudents();
            LoadDalykas();
            DisplayPazymiai();
            label4.Text = $"{username}";
            label5.Text = $"{password}";


        }
        private void LoadGroups()
        {
            try
            {
                DataTable dt = PP.GetGroups();
                cmbGroups.DataSource = dt;
                cmbGroups.DisplayMember = "groupName";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading groups: {ex.Message}");
            }
        }

        private void LoadStudents()
        {
            try
            {
                DataTable dt = PP.GetStudents();
                cmbStudentsN.DataSource = dt;
                cmbStudentsN.DisplayMember = "studentName";
                cmbStudentsS.DataSource = dt;
                cmbStudentsS.DisplayMember = "studentSur";

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading professors: {ex.Message}");
            }
        }

        private void LoadDalykas()
        {
            try

            {
                DataTable dt = PP.GetSubjects();
                cmbDalykas.DataSource = dt;
                cmbDalykas.DisplayMember = "dalykoName";
           
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading professors: {ex.Message}");
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            string groupName = ((DataRowView)cmbGroups.SelectedItem)["groupName"].ToString(); ;
            string studentName = ((DataRowView)cmbStudentsN.SelectedItem)["studentName"].ToString();
            string studentSur = ((DataRowView)cmbStudentsS.SelectedItem)["studentSur"].ToString(); ;
            string subjectName = ((DataRowView)cmbDalykas.SelectedItem)["dalykoName"].ToString(); ;
            string paz = GradeBox.Text;
            bool success = PP.AddGrade(groupName, studentName, studentSur, subjectName, paz);
            if (success)
            {
                MessageBox.Show("Subject added successfully!");
                DisplayPazymiai();
            }
            else
            {
                MessageBox.Show("Error adding subject.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(GradeBox.Text) || string.IsNullOrEmpty(IDBox.Text))
            {
                MessageBox.Show("Please fill in all fields, including the ID and new grade.");
                return;
            }

            try
            {
                int pazID = int.Parse(IDBox.Text); 
                int newGrade = int.Parse(GradeBox.Text); 

                bool success = PP.EditGrade(pazID, newGrade);

                if (success)
                {
                    MessageBox.Show("Grade updated successfully!");
                    DisplayPazymiai(); 
                }
                else
                {
                    MessageBox.Show("Error updating grade. Ensure the ID is correct.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Close();
        }

        public void DisplayPazymiai()
        {
    
            PridPaz pazymiai = new PridPaz();

            DataTable dt = pazymiai.GetPazymiai();

            dataGridView1.DataSource = dt;
            
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
