﻿namespace Akademine_Sistema
{
    partial class Form7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            cmbGroups = new ComboBox();
            cmbStudentsN = new ComboBox();
            cmbStudentsS = new ComboBox();
            dataGridView1 = new DataGridView();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            label12 = new Label();
            GradeBox = new TextBox();
            IDBox = new TextBox();
            label13 = new Label();
            cmbDalykas = new ComboBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(0, 192, 0);
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(147, 45);
            label1.TabIndex = 0;
            label1.Text = "Pažymiai";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.FromArgb(0, 192, 0);
            label2.Location = new Point(12, 143);
            label2.Name = "label2";
            label2.Size = new Size(83, 32);
            label2.TabIndex = 1;
            label2.Text = "Vardas";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.FromArgb(0, 192, 0);
            label3.Location = new Point(12, 198);
            label3.Name = "label3";
            label3.Size = new Size(97, 32);
            label3.TabIndex = 2;
            label3.Text = "Pavardė";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.White;
            label4.Location = new Point(129, 143);
            label4.Name = "label4";
            label4.Size = new Size(54, 32);
            label4.TabIndex = 3;
            label4.Text = "text";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(129, 198);
            label5.Name = "label5";
            label5.Size = new Size(54, 32);
            label5.TabIndex = 4;
            label5.Text = "text";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.FromArgb(0, 192, 0);
            label6.Location = new Point(349, 350);
            label6.Name = "label6";
            label6.Size = new Size(104, 32);
            label6.TabIndex = 5;
            label6.Text = "Pažymys";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.FromArgb(0, 192, 0);
            label7.Location = new Point(12, 58);
            label7.Name = "label7";
            label7.Size = new Size(165, 37);
            label7.TabIndex = 7;
            label7.Text = "Dėstyotjas/a";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.FromArgb(0, 192, 0);
            label8.Location = new Point(349, 58);
            label8.Name = "label8";
            label8.Size = new Size(158, 37);
            label8.TabIndex = 8;
            label8.Text = "Studentas/ė";
            label8.Click += label8_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.FromArgb(0, 192, 0);
            label9.Location = new Point(349, 198);
            label9.Name = "label9";
            label9.Size = new Size(97, 32);
            label9.TabIndex = 10;
            label9.Text = "Pavardė";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.FromArgb(0, 192, 0);
            label10.Location = new Point(349, 152);
            label10.Name = "label10";
            label10.Size = new Size(83, 32);
            label10.TabIndex = 9;
            label10.Text = "Vardas";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label11.ForeColor = Color.FromArgb(0, 192, 0);
            label11.Location = new Point(349, 107);
            label11.Name = "label11";
            label11.Size = new Size(79, 32);
            label11.TabIndex = 11;
            label11.Text = "Grupė";
            // 
            // cmbGroups
            // 
            cmbGroups.FormattingEnabled = true;
            cmbGroups.Location = new Point(459, 118);
            cmbGroups.Name = "cmbGroups";
            cmbGroups.Size = new Size(103, 23);
            cmbGroups.TabIndex = 12;
            cmbGroups.SelectedIndexChanged += comboBox2_SelectedIndexChanged;
            // 
            // cmbStudentsN
            // 
            cmbStudentsN.FormattingEnabled = true;
            cmbStudentsN.Location = new Point(459, 158);
            cmbStudentsN.Name = "cmbStudentsN";
            cmbStudentsN.Size = new Size(199, 23);
            cmbStudentsN.TabIndex = 13;
            // 
            // cmbStudentsS
            // 
            cmbStudentsS.FormattingEnabled = true;
            cmbStudentsS.Location = new Point(459, 207);
            cmbStudentsS.Name = "cmbStudentsS";
            cmbStudentsS.Size = new Size(199, 23);
            cmbStudentsS.TabIndex = 14;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(12, 416);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(789, 277);
            dataGridView1.TabIndex = 15;
            // 
            // button1
            // 
            button1.BackColor = Color.Black;
            button1.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.Lime;
            button1.Location = new Point(685, 82);
            button1.Name = "button1";
            button1.Size = new Size(96, 41);
            button1.TabIndex = 16;
            button1.Text = "Pridėti";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.Black;
            button2.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.Yellow;
            button2.Location = new Point(685, 158);
            button2.Name = "button2";
            button2.Size = new Size(96, 41);
            button2.TabIndex = 17;
            button2.Text = "Pakeisti";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.Black;
            button3.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.ForeColor = Color.FromArgb(192, 64, 0);
            button3.Location = new Point(685, 9);
            button3.Name = "button3";
            button3.Size = new Size(116, 41);
            button3.TabIndex = 18;
            button3.Text = "Atsijungti";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label12.ForeColor = Color.FromArgb(0, 192, 0);
            label12.Location = new Point(349, 296);
            label12.Name = "label12";
            label12.Size = new Size(37, 32);
            label12.TabIndex = 19;
            label12.Text = "ID";
            // 
            // GradeBox
            // 
            GradeBox.Location = new Point(459, 359);
            GradeBox.Name = "GradeBox";
            GradeBox.Size = new Size(48, 23);
            GradeBox.TabIndex = 20;
            // 
            // IDBox
            // 
            IDBox.Location = new Point(459, 307);
            IDBox.Name = "IDBox";
            IDBox.Size = new Size(199, 23);
            IDBox.TabIndex = 21;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label13.ForeColor = Color.FromArgb(0, 192, 0);
            label13.Location = new Point(349, 249);
            label13.Name = "label13";
            label13.Size = new Size(95, 32);
            label13.TabIndex = 22;
            label13.Text = "Dalykas";
            // 
            // cmbDalykas
            // 
            cmbDalykas.FormattingEnabled = true;
            cmbDalykas.Location = new Point(459, 258);
            cmbDalykas.Name = "cmbDalykas";
            cmbDalykas.Size = new Size(199, 23);
            cmbDalykas.TabIndex = 23;
            // 
            // Form7
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(32, 32, 32);
            ClientSize = new Size(822, 705);
            Controls.Add(cmbDalykas);
            Controls.Add(label13);
            Controls.Add(IDBox);
            Controls.Add(GradeBox);
            Controls.Add(label12);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(dataGridView1);
            Controls.Add(cmbStudentsS);
            Controls.Add(cmbStudentsN);
            Controls.Add(cmbGroups);
            Controls.Add(label11);
            Controls.Add(label9);
            Controls.Add(label10);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form7";
            Text = "Form7";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private ComboBox cmbGroups;
        private ComboBox cmbStudentsN;
        private ComboBox cmbStudentsS;
        private DataGridView dataGridView1;
        private Button button1;
        private Button button2;
        private Button button3;
        private Label label12;
        private TextBox GradeBox;
        private TextBox IDBox;
        private Label label13;
        private ComboBox cmbDalykas;
    }
}